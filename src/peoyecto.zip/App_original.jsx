


function App() {

  return (
    <>
      <div>
   <h1 className="text-3xl font-bold underline">
    Hello world React Vite Tailwind CSS!
  </h1>
      </div>
     
    </>
  )
}

export default App
