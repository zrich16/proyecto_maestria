
import AppRoutes from '../src/rutas/routes';
import Login from './pages/login/login'


function App() {
    return (
    <div>
      <AppRoutes />
    </div>
  );

//   return (
//     <>
//  <div className="w-full">
//       <Login />
//     </div> 

  
//     </>
//   )
}

export default App
